@EndUserText.label: 'Import Consignment Excel Upload'
define root abstract entity ZD_MM_UPLOAD_EXCEL
{
  _StreamProperties : association [1] to ZD_MM_FILE_STREAM on 1 = 1;
}
