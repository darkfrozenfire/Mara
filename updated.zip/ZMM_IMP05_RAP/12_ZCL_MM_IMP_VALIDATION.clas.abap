" Optional helper class. Keep validation in the behavior pool for the first implementation.
" This class is intentionally empty so the RAP package does not depend on an additional
" custom message class during the initial activation.
CLASS zcl_mm_imp_validation DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC.
ENDCLASS.

CLASS zcl_mm_imp_validation IMPLEMENTATION.
ENDCLASS.
