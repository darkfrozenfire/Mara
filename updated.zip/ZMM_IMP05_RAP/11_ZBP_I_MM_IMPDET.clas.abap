CLASS zbp_i_mm_impdet DEFINITION
  PUBLIC
  FINAL
  FOR BEHAVIOR OF zi_mm_impdet.

  PRIVATE SECTION.

    METHODS get_global_authorizations
      FOR GLOBAL AUTHORIZATION
      IMPORTING REQUEST requested_authorizations FOR ImportConsignment
      RESULT result.

    METHODS setauditfields
      FOR DETERMINE ON SAVE
      IMPORTING keys FOR ImportConsignment~SetAuditFields.

    METHODS validatebusinessdata
      FOR VALIDATE ON SAVE
      IMPORTING keys FOR ImportConsignment~ValidateBusinessData.

    METHODS deleterecord
      FOR MODIFY
      IMPORTING keys FOR ACTION ImportConsignment~DeleteRecord.

    METHODS excelfupload
      FOR MODIFY
      IMPORTING keys FOR ACTION ImportConsignment~ExcelUpload.

    TYPES:
      BEGIN OF ty_excel_row,
        bol_awb          TYPE string,
        bol_awb_dt       TYPE string,
        bol_awb_cnt      TYPE string,
        rodtep_lic_no    TYPE string,
        rodtep_lic_dt    TYPE string,
        rodtep_lic_val   TYPE string,
        boe_ex_rt        TYPE string,
        ad_co            TYPE string,
        por_co           TYPE string,
        lc_no            TYPE string,
        lc_dt            TYPE string,
        duty_chl_no      TYPE string,
        duty_chl_dt      TYPE string,
        duty_chl_val     TYPE string,
        inv_pay_ref      TYPE string,
        inv_pay_dt       TYPE string,
        boe_stat         TYPE string,
        sims_ref         TYPE string,
      END OF ty_excel_row.

    CLASS-METHODS parse_date
      IMPORTING iv_value TYPE string
      RETURNING VALUE(rv_date) TYPE d
      RAISING cx_sy_conversion_no_date.

    CLASS-METHODS read_excel
      IMPORTING iv_file_content TYPE xstring
      RETURNING VALUE(rt_rows) TYPE STANDARD TABLE OF ty_excel_row
      RAISING cx_root.

ENDCLASS.


CLASS zbp_i_mm_impdet IMPLEMENTATION.

  METHOD get_global_authorizations.

    IF requested_authorizations-%create = if_abap_behv=>mk-on.
      AUTHORITY-CHECK OBJECT 'ZMM_IMP06'
        ID 'ACTVT' FIELD '01'.
      result-%create = COND #(
        WHEN sy-subrc = 0 THEN if_abap_behv=>auth-allowed
        ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.

    IF requested_authorizations-%update = if_abap_behv=>mk-on.
      AUTHORITY-CHECK OBJECT 'ZMM_IMP06'
        ID 'ACTVT' FIELD '02'.
      result-%update = COND #(
        WHEN sy-subrc = 0 THEN if_abap_behv=>auth-allowed
        ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.

    IF requested_authorizations-%action-DeleteRecord = if_abap_behv=>mk-on.
      AUTHORITY-CHECK OBJECT 'ZMM_IMP06'
        ID 'ACTVT' FIELD '06'.
      result-%action-DeleteRecord = COND #(
        WHEN sy-subrc = 0 THEN if_abap_behv=>auth-allowed
        ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.

    IF requested_authorizations-%action-ExcelUpload = if_abap_behv=>mk-on.
      AUTHORITY-CHECK OBJECT 'ZMM_IMP06'
        ID 'ACTVT' FIELD '01'.
      result-%action-ExcelUpload = COND #(
        WHEN sy-subrc = 0 THEN if_abap_behv=>auth-allowed
        ELSE if_abap_behv=>auth-unauthorized ).
    ENDIF.

  ENDMETHOD.


  METHOD parse_date.

    DATA(lv_value) = condense( iv_value ).

    IF lv_value IS INITIAL.
      rv_date = '00000000'.
      RETURN.
    ENDIF.

    IF strlen( lv_value ) = 10
       AND lv_value+2(1) = '.'
       AND lv_value+5(1) = '.'.
      rv_date = CONV d( |{ lv_value+6(4) }{ lv_value+3(2) }{ lv_value+0(2) }| ).
    ELSEIF strlen( lv_value ) = 8.
      rv_date = CONV d( lv_value ).
    ELSE.
      RAISE EXCEPTION TYPE cx_sy_conversion_no_date.
    ENDIF.

  ENDMETHOD.


  METHOD read_excel.

    DATA(lo_document) =
      xco_cp_xlsx=>document->for_file_content( iv_file_content ).

    DATA(lo_read_access) = lo_document->read_access( ).

    DATA(lo_worksheet) =
      lo_read_access->get_workbook( )->worksheet->at_position( 1 ).

    DATA(lv_row) = 3.

    WHILE lv_row <= 999999.

      DATA(ls_row) = VALUE ty_excel_row( ).
      DATA(lv_empty_row) = abap_true.

      DO 18 TIMES.
        DATA(lv_col) = sy-index.
        DATA(lv_value) = VALUE string( ).

        DATA(lo_cursor) = lo_worksheet->cursor(
          io_column = xco_cp_xlsx=>coordinate->for_numeric_value( lv_col )
          io_row    = xco_cp_xlsx=>coordinate->for_numeric_value( lv_row ) ).

        IF lo_cursor->has_cell( ) = abap_true
           AND lo_cursor->get_cell( )->has_value( ) = abap_true.
          lo_cursor->get_cell( )->get_value(
            )->set_transformation(
              xco_cp_xlsx_read_access=>value_transformation->string_value
            )->write_to( REF #( lv_value ) ).
        ENDIF.

        IF lv_value IS NOT INITIAL.
          lv_empty_row = abap_false.
        ENDIF.

        CASE lv_col.
          WHEN 1.  ls_row-bol_awb        = lv_value.
          WHEN 2.  ls_row-bol_awb_dt     = lv_value.
          WHEN 3.  ls_row-bol_awb_cnt    = lv_value.
          WHEN 4.  ls_row-rodtep_lic_no  = lv_value.
          WHEN 5.  ls_row-rodtep_lic_dt  = lv_value.
          WHEN 6.  ls_row-rodtep_lic_val = lv_value.
          WHEN 7.  ls_row-boe_ex_rt      = lv_value.
          WHEN 8.  ls_row-ad_co          = lv_value.
          WHEN 9.  ls_row-por_co         = lv_value.
          WHEN 10. ls_row-lc_no          = lv_value.
          WHEN 11. ls_row-lc_dt          = lv_value.
          WHEN 12. ls_row-duty_chl_no    = lv_value.
          WHEN 13. ls_row-duty_chl_dt    = lv_value.
          WHEN 14. ls_row-duty_chl_val   = lv_value.
          WHEN 15. ls_row-inv_pay_ref    = lv_value.
          WHEN 16. ls_row-inv_pay_dt     = lv_value.
          WHEN 17. ls_row-boe_stat       = lv_value.
          WHEN 18. ls_row-sims_ref       = lv_value.
        ENDCASE.
      ENDDO.

      IF lv_empty_row = abap_false.
        APPEND ls_row TO rt_rows.
      ELSEIF lines( rt_rows ) > 0.
        EXIT.
      ENDIF.

      lv_row += 1.

      IF lines( rt_rows ) >= 100000.
        EXIT.
      ENDIF.
    ENDWHILE.

  ENDMETHOD.


  METHOD setauditfields.

    READ ENTITIES OF zi_mm_impdet IN LOCAL MODE
      ENTITY ImportConsignment
      ALL FIELDS WITH CORRESPONDING #( keys )
      RESULT DATA(lt_data).

    MODIFY ENTITIES OF zi_mm_impdet IN LOCAL MODE
      ENTITY ImportConsignment
      UPDATE FIELDS ( CreatedBy CreatedOn CreatedAt DeleteFlag )
      WITH VALUE #(
        FOR ls_data IN lt_data
        (
          %tky       = ls_data-%tky
          CreatedBy  = sy-uname
          CreatedOn  = sy-datum
          CreatedAt  = sy-uzeit
          DeleteFlag = space
        ) )
      FAILED DATA(lt_failed)
      REPORTED DATA(lt_reported).

  ENDMETHOD.


  METHOD validatebusinessdata.

    READ ENTITIES OF zi_mm_impdet IN LOCAL MODE
      ENTITY ImportConsignment
      FIELDS ( BolAwb BolAwbDate BolAwbCount RodtepLicenseNo )
      WITH CORRESPONDING #( keys )
      RESULT DATA(lt_data).

    LOOP AT lt_data ASSIGNING FIELD-SYMBOL(<ls_data>).

      IF <ls_data>-BolAwb IS INITIAL.
        APPEND VALUE #( %tky = <ls_data>-%tky ) TO failed-ImportConsignment.
        APPEND VALUE #(
          %tky = <ls_data>-%tky
          %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error
            text = 'Bill of Lading / Air Way Bill No. is mandatory.' ) )
          TO reported-ImportConsignment.
        CONTINUE.
      ENDIF.

      IF <ls_data>-BolAwbDate IS INITIAL OR
         <ls_data>-BolAwbDate > sy-datum.
        APPEND VALUE #( %tky = <ls_data>-%tky ) TO failed-ImportConsignment.
        APPEND VALUE #(
          %tky = <ls_data>-%tky
          %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error
            text = 'Bill/AWB date is invalid or is in the future.' ) )
          TO reported-ImportConsignment.
      ENDIF.

      IF <ls_data>-BolAwbCount IS INITIAL.
        APPEND VALUE #( %tky = <ls_data>-%tky ) TO failed-ImportConsignment.
        APPEND VALUE #(
          %tky = <ls_data>-%tky
          %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error
            text = 'Bill/AWB count is mandatory.' ) )
          TO reported-ImportConsignment.
      ENDIF.

      IF <ls_data>-RodtepLicenseNo IS INITIAL.
        APPEND VALUE #( %tky = <ls_data>-%tky ) TO failed-ImportConsignment.
        APPEND VALUE #(
          %tky = <ls_data>-%tky
          %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error
            text = 'RoDTEP License No. is mandatory because it is part of the database key.' ) )
          TO reported-ImportConsignment.
      ENDIF.

    ENDLOOP.

  ENDMETHOD.


  METHOD deleterecord.

    MODIFY ENTITIES OF zi_mm_impdet IN LOCAL MODE
      ENTITY ImportConsignment
      UPDATE FIELDS ( DeleteFlag DeletedOn DeletedBy DeletedAt )
      WITH VALUE #(
        FOR ls_key IN keys
        (
          %tky      = ls_key-%tky
          DeleteFlag = 'X'
          DeletedOn  = sy-datum
          DeletedBy  = sy-uname
          DeletedAt  = sy-uzeit
        ) )
      FAILED DATA(lt_failed)
      REPORTED DATA(lt_reported).

    failed = CORRESPONDING #( DEEP lt_failed ).
    reported = CORRESPONDING #( DEEP lt_reported ).

    IF failed-ImportConsignment IS INITIAL.
      APPEND VALUE #(
        %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-success
          text = 'Selected consignment record(s) deleted successfully.' ) )
        TO reported-%other.
    ENDIF.

  ENDMETHOD.


  METHOD excelfupload.

    LOOP AT keys ASSIGNING FIELD-SYMBOL(<ls_key>).

      DATA(lv_file_content) =
        CONV xstring( <ls_key>-%param-_StreamProperties-StreamProperty ).

      DATA(lv_file_name) =
        CONV string( <ls_key>-%param-_StreamProperties-FileName ).

      DATA(lv_mime_type) =
        CONV string( <ls_key>-%param-_StreamProperties-MimeType ).

      IF lv_file_content IS INITIAL.
        APPEND VALUE #(
          %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error
            text = 'Please select an Excel file.' ) ) TO reported-%other.
        CONTINUE.
      ENDIF.

      IF to_upper( lv_file_name ) NP '*.XLSX'.
        APPEND VALUE #(
          %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error
            text = 'Only .XLSX files are supported.' ) ) TO reported-%other.
        CONTINUE.
      ENDIF.

      IF lv_mime_type IS NOT INITIAL AND
         lv_mime_type <> 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'.
        APPEND VALUE #(
          %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error
            text = 'Invalid Excel MIME type.' ) ) TO reported-%other.
        CONTINUE.
      ENDIF.

      TRY.
          DATA(lt_rows) = read_excel( lv_file_content ).
        CATCH cx_root INTO DATA(lx_excel).
          APPEND VALUE #(
            %msg = new_message_with_text(
              severity = if_abap_behv_message=>severity-error
              text = |Excel processing failed: { lx_excel->get_text( ) }| ) ) TO reported-%other.
          CONTINUE.
      ENDTRY.

      IF lt_rows IS INITIAL.
        APPEND VALUE #(
          %msg = new_message_with_text(
            severity = if_abap_behv_message=>severity-error
            text = 'The Excel file contains no data rows.' ) ) TO reported-%other.
        CONTINUE.
      ENDIF.

      LOOP AT lt_rows ASSIGNING FIELD-SYMBOL(<ls_row>).

        TRY.
            DATA(lv_bol_date) = parse_date( <ls_row>-bol_awb_dt ).
            DATA(lv_rodtep_date) = COND d(
              WHEN <ls_row>-rodtep_lic_dt IS INITIAL
              THEN '00000000'
              ELSE parse_date( <ls_row>-rodtep_lic_dt ) ).
            DATA(lv_lc_date) = COND d(
              WHEN <ls_row>-lc_dt IS INITIAL
              THEN '00000000'
              ELSE parse_date( <ls_row>-lc_dt ) ).
            DATA(lv_duty_date) = COND d(
              WHEN <ls_row>-duty_chl_dt IS INITIAL
              THEN '00000000'
              ELSE parse_date( <ls_row>-duty_chl_dt ) ).
            DATA(lv_inv_date) = COND d(
              WHEN <ls_row>-inv_pay_dt IS INITIAL
              THEN '00000000'
              ELSE parse_date( <ls_row>-inv_pay_dt ) ).
          CATCH cx_sy_conversion_no_date.
            APPEND VALUE #(
              %msg = new_message_with_text(
                severity = if_abap_behv_message=>severity-error
                text = |Invalid date in Excel row { sy-tabix }.| ) ) TO reported-%other.
            CONTINUE.
        ENDTRY.

        IF lv_bol_date IS INITIAL OR lv_bol_date > sy-datum.
          APPEND VALUE #(
            %msg = new_message_with_text(
              severity = if_abap_behv_message=>severity-error
              text = |BL/AWB date is invalid or future in Excel row { sy-tabix }.| ) ) TO reported-%other.
          CONTINUE.
        ENDIF.

        IF <ls_row>-bol_awb IS INITIAL OR
           <ls_row>-bol_awb_cnt IS INITIAL OR
           <ls_row>-rodtep_lic_no IS INITIAL.
          APPEND VALUE #(
            %msg = new_message_with_text(
              severity = if_abap_behv_message=>severity-error
              text = |Mandatory key value missing in Excel row { sy-tabix }.| ) ) TO reported-%other.
          CONTINUE.
        ENDIF.

        SELECT SINGLE bol_awb
          FROM zmm_impdet_upld
          WHERE bol_awb       = @CONV z_bolnr( |{ <ls_row>-bol_awb ALPHA = IN }| )
            AND bol_awb_dt    = @lv_bol_date
            AND bol_awb_cnt   = @CONV abap.char(3)( <ls_row>-bol_awb_cnt )
            AND rodtep_lic_no = @CONV abap.numc(15)( <ls_row>-rodtep_lic_no )
          INTO @DATA(lv_existing).

        IF sy-subrc = 0.
          APPEND VALUE #(
            %msg = new_message_with_text(
              severity = if_abap_behv_message=>severity-error
              text = |Duplicate record in Excel row { sy-tabix }.| ) ) TO reported-%other.
          CONTINUE.
        ENDIF.

        MODIFY ENTITIES OF zi_mm_impdet IN LOCAL MODE
          ENTITY ImportConsignment
          CREATE FIELDS (
            BolAwb BolAwbDate BolAwbCount RodtepLicenseNo
            RodtepLicenseDate RodtepLicenseValue BoeExchangeRate
            AdCode PortCode LcNumber LcDate DutyChallanNo DutyChallanDate
            DutyChallanValue InvoicePaymentRef InvoicePaymentDate
            BoeStatus SimsReference )
          WITH VALUE #(
            (
              %cid                 = |UPL_{ sy-tabix }|
              BolAwb               = |{ <ls_row>-bol_awb ALPHA = IN }|
              BolAwbDate           = lv_bol_date
              BolAwbCount          = CONV #( <ls_row>-bol_awb_cnt )
              RodtepLicenseNo      = CONV #( <ls_row>-rodtep_lic_no )
              RodtepLicenseDate    = lv_rodtep_date
              RodtepLicenseValue   = CONV #( <ls_row>-rodtep_lic_val )
              BoeExchangeRate      = CONV #( <ls_row>-boe_ex_rt )
              AdCode               = CONV #( <ls_row>-ad_co )
              PortCode             = CONV #( <ls_row>-por_co )
              LcNumber             = CONV #( <ls_row>-lc_no )
              LcDate               = lv_lc_date
              DutyChallanNo        = CONV #( <ls_row>-duty_chl_no )
              DutyChallanDate      = lv_duty_date
              DutyChallanValue     = CONV #( <ls_row>-duty_chl_val )
              InvoicePaymentRef    = CONV #( <ls_row>-inv_pay_ref )
              InvoicePaymentDate   = lv_inv_date
              BoeStatus            = CONV #( <ls_row>-boe_stat )
              SimsReference        = CONV #( <ls_row>-sims_ref )
            ) )
          FAILED DATA(lt_create_failed)
          REPORTED DATA(lt_create_reported).

        IF lt_create_failed IS NOT INITIAL.
          APPEND LINES OF lt_create_reported TO reported-%other.
        ENDIF.

      ENDLOOP.

      APPEND VALUE #(
        %msg = new_message_with_text(
          severity = if_abap_behv_message=>severity-success
          text = |Excel upload processing completed for { lines( lt_rows ) } rows.| ) ) TO reported-%other.

    ENDLOOP.

  ENDMETHOD.

ENDCLASS.
