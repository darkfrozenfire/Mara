@AccessControl.authorizationCheck: #CHECK
@EndUserText.label: 'Consignment Import Data'
define root view entity ZI_MM_IMPDET
  as select from zmm_impdet_upld
  where delflg <> 'X'
{
  key bol_awb       as BolAwb,
  key bol_awb_dt    as BolAwbDate,
  key bol_awb_cnt   as BolAwbCount,
  key rodtep_lic_no as RodtepLicenseNo,

      rodtep_lic_dt   as RodtepLicenseDate,
      rodtep_lic_val  as RodtepLicenseValue,
      boe_ex_rt       as BoeExchangeRate,
      ad_co           as AdCode,
      por_co          as PortCode,
      lc_no           as LcNumber,
      lc_dt           as LcDate,
      duty_chl_no     as DutyChallanNo,
      duty_chl_dt     as DutyChallanDate,
      duty_chl_val    as DutyChallanValue,
      inv_pay_ref     as InvoicePaymentRef,
      inv_pay_dt      as InvoicePaymentDate,
      boe_stat        as BoeStatus,
      sims_ref        as SimsReference,

      suppinv_dtyp    as SupplierInvoiceDocType,
      suppinv_docno   as SupplierInvoiceDocNo,
      billlad_dtyp    as BillOfLadingDocType,
      billlad_docno   as BillOfLadingDocNo,
      boe_dtyp        as BillOfEntryDocType,
      boe_docno       as BillOfEntryDocNo,
      duty_chl_dtyp   as DutyPaymentDocType,
      duty_chl_no_idc as DutyPaymentDocNo,
      imp_oth_dtyp    as OtherDocType,
      imp_others_no   as OtherDocNo,

      ernam           as CreatedBy,
      erdat           as CreatedOn,
      ztime_creat     as CreatedAt,
      zcrtip          as CreatedIp,
      zdldat          as DeletedOn,
      zdelnam         as DeletedBy,
      ztime_del       as DeletedAt,
      zdelip          as DeletedIp,
      delflg          as DeleteFlag
}
