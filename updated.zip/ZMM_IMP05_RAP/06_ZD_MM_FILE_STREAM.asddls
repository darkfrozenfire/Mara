@EndUserText.label: 'Excel file upload stream'
define root abstract entity ZD_MM_FILE_STREAM
{
  @Semantics.largeObject.mimeType: 'MimeType'
  @Semantics.largeObject.fileName: 'FileName'
  @Semantics.largeObject.contentDispositionPreference: #INLINE
  @Core.AcceptableMediaTypes: [ 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ]
  StreamProperty : abap.rawstring(0);

  @UI.hidden: true
  MimeType : abap.char(128);

  @UI.hidden: true
  FileName : abap.char(128);
}
